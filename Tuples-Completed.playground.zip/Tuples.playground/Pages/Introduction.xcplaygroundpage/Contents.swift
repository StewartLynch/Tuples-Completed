/*:
 # Swift Tuples

 This playground is designed to introduce you to Swift Tuples.

 If you hit problems or have questions, you're welcome to DM me on Mastodon [@StewartLynch@iosdev.space](https://iosdev.space/@StewartLynch) or email <slynch@createchsol.com>.

 I am also on Twitter (less and less) [@StewartLynch](https://twitter.com/StewartLynch)

 &nbsp;

 ## Contents

 * [The Basics](The%20Basics)
 * [Practical Examples](Practical%20Examples)

 &nbsp;
 
 [Next >](@next)
 */
